from setuptools import setup

setup(
    package_data={
        'pyedurov2.web': ['*'],
        'pyedurov2.web.scripts': ['*'],
        'pyedurov2.web.static': ['*'],
    }
)